import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';

const bg = Color(0xFF070B14);
const panel = Color(0xFF111B2B);
const neon = Color(0xFF168BFF);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MusicalWorldApp());
}

class MusicalWorldApp extends StatelessWidget {
  const MusicalWorldApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Musical World',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: const ColorScheme.dark(primary: neon, surface: panel),
        useMaterial3: true,
      ),
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        if (snapshot.data != null) return const MusicHome();
        return const AuthScreen();
      },
    );
  }
}

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  final name = TextEditingController();
  bool isLogin = true;
  bool busy = false;
  String? error;

  Future<void> submit() async {
    setState(() { busy = true; error = null; });
    try {
      if (isLogin) {
        await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: email.text.trim(), password: password.text,
        );
      } else {
        final credential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: email.text.trim(), password: password.text,
        );
        if (name.text.trim().isNotEmpty) {
          await credential.user?.updateDisplayName(name.text.trim());
        }
      }
    } on FirebaseAuthException catch (e) {
      setState(() => error = e.message ?? 'Please check your details.');
    } catch (_) {
      setState(() => error = 'Setup incomplete. Please check Firebase configuration.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    email.dispose(); password.dispose(); name.dispose();
    super.dispose();
  }

  InputDecoration field(String label, IconData icon) => InputDecoration(
    labelText: label, prefixIcon: Icon(icon, color: neon),
    filled: true, fillColor: panel,
    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Icon(Icons.graphic_eq_rounded, size: 76, color: neon),
                  const SizedBox(height: 12),
                  const Text('Musical World', textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 32, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 8),
                  const Text('Feel every beat. Live every song.',
                    textAlign: TextAlign.center, style: TextStyle(color: Colors.white60)),
                  const SizedBox(height: 36),
                  Text(isLogin ? 'Welcome back' : 'Create your account',
                    style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 18),
                  if (!isLogin) ...[
                    TextField(controller: name, decoration: field('Your name', Icons.person_outline)),
                    const SizedBox(height: 14),
                  ],
                  TextField(controller: email, keyboardType: TextInputType.emailAddress,
                    decoration: field('Email address', Icons.email_outlined)),
                  const SizedBox(height: 14),
                  TextField(controller: password, obscureText: true,
                    decoration: field('Password (at least 6 characters)', Icons.lock_outline)),
                  if (error != null) ...[
                    const SizedBox(height: 12),
                    Text(error!, style: const TextStyle(color: Colors.redAccent)),
                  ],
                  const SizedBox(height: 22),
                  FilledButton(
                    onPressed: busy ? null : submit,
                    style: FilledButton.styleFrom(
                      backgroundColor: neon, foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                    child: busy ? const CircularProgressIndicator() :
                      Text(isLogin ? 'LOG IN' : 'SIGN UP', style: const TextStyle(fontWeight: FontWeight.bold)),
                  ),
                  TextButton(
                    onPressed: () => setState(() { isLogin = !isLogin; error = null; }),
                    child: Text(isLogin ? "New here? Create an account" : "Already registered? Log in"),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class MusicHome extends StatelessWidget {
  const MusicHome({super.key});
  static const songs = [
    ('Midnight Drive', 'Neon Avenue', Icons.nightlight_round),
    ('Ocean Air', 'Blue Horizon', Icons.waves),
    ('New Beginnings', 'The Ambient Project', Icons.wb_sunny_outlined),
    ('Electric Dreams', 'Nova Beats', Icons.bolt),
  ];

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          Icon(Icons.graphic_eq, color: neon),
          SizedBox(width: 8),
          Text('Musical '),
          Text('World', style: TextStyle(color: neon, fontWeight: FontWeight.bold)),
        ]),
        actions: [
          IconButton(
            tooltip: 'Log out',
            onPressed: () => FirebaseAuth.instance.signOut(),
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text('Hello, ${user?.displayName?.isNotEmpty == true ? user!.displayName : 'Music lover'}!',
            style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          const Text('Find your sound. Find your world.', style: TextStyle(color: Colors.white60)),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              gradient: const LinearGradient(colors: [Color(0xFF0756AD), Color(0xFF101D39)]),
            ),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('MUSICAL WORLD PICKS', style: TextStyle(color: Colors.white70, letterSpacing: 1.2)),
              SizedBox(height: 10),
              Text('Discover\\nnew sounds.', style: TextStyle(fontSize: 29, fontWeight: FontWeight.bold)),
              SizedBox(height: 8),
              Text('Independent sounds. Fresh discoveries.'),
            ]),
          ),
          const SizedBox(height: 28),
          const Text('Featured tracks', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          ...songs.map((song) => Card(
            color: panel,
            child: ListTile(
              leading: CircleAvatar(backgroundColor: const Color(0xFF12345A),
                child: Icon(song.$3, color: neon)),
              title: Text(song.$1),
              subtitle: Text(song.$2),
              trailing: const Icon(Icons.play_circle_fill, color: neon, size: 30),
              onTap: () => ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Audio playback will be connected in the next build.')),
              ),
            ),
          )),
          const SizedBox(height: 16),
          const Text('Demo tracks only — licensed audio will be added before release.',
            style: TextStyle(color: Colors.white54, fontSize: 12)),
        ],
      ),
    );
  }
}
