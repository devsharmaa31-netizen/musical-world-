# Musical World – Flutter starter

This starter includes:
- Black + blue neon UI
- Email/password sign-up and login using Firebase Authentication
- Signed-in home screen
- Sign out
- Demo track list (not real playable audio yet)

## Important: Firebase setup is required
Authentication cannot work until a Firebase project is connected.

1. Create a free Firebase project at https://console.firebase.google.com/
2. Add an Android app to the Firebase project. The Android package name should be:
   `com.example.musical_world`
3. In Firebase Console → Authentication → Sign-in method, enable **Email/Password**.
4. Install FlutterFire CLI on a computer or compatible cloud development environment and run:
   `flutterfire configure`
   This creates `lib/firebase_options.dart`.
5. Update `main.dart` initialization to:
   `await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);`
   and add `import 'firebase_options.dart';` at the top.

The current starter uses `Firebase.initializeApp()` as a placeholder. It will not authenticate until the Firebase app configuration is added.

## Build
With Flutter installed:
`flutter pub get`
`flutter run`

For Android:
`flutter build apk --release`

iOS builds require macOS/Xcode or a suitable cloud macOS build service.
